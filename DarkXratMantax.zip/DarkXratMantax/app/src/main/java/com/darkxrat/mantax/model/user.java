package com.darkxrat.mantax.model;

public class User {
    private int id;
    private String username;
    private String password;
    private String role;
    private String expired;
    private boolean isActive;

    public User() {}

    public User(int id, String username, String password, String role, String expired) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.expired = expired;
        this.isActive = true;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getExpired() { return expired; }
    public void setExpired(String expired) { this.expired = expired; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
}